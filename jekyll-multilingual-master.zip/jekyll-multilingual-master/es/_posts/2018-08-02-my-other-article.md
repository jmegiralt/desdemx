---
layout: post
title: Mi Otro Artículo
lang: es
lang-ref: my-other-article
---

Este es mi otro artículo.