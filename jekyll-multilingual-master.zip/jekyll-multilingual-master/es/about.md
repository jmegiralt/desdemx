---
title: Sobre el Autor
layout: page
lang: es
lang-ref: about
---

![](/public/img/soccer-chimp.jpg)

Solo un chimpancé amante del fútbol que intenta encontrar su camino en el mundo.