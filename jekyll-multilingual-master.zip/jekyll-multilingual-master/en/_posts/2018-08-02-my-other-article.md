---
layout: post
title: My Other Article
lang: en
lang-ref: my-other-article
---

This is my other article.