---
title: About the Author
layout: page
lang: en
lang-ref: about

---
![](/public/img/soccer-chimp.jpg)

Just a soccer-loving chimp trying to find his way in the world.